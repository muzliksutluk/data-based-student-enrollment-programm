﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace project_deniz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static SQLiteConnection con = new SQLiteConnection("Data source = .\\StudentDB.db;Versiyon = 3");
        public static SQLiteDataAdapter adapter = new SQLiteDataAdapter("Select * from Student", con);
        public static SQLiteCommand cmd = new SQLiteCommand();
        public static SQLiteDataReader okuyucu;
        DataTable dt;
        private void Form1_Load(object sender, EventArgs e)
        {
            Listeleme();
        }

        public void Listeleme()
        {
            con.Open();
            dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandText = "Insert into Student(ID, Name, Surname, Class, Gender, CallNumber, ParentName, ParentCall) values(' " + textBox1.Text + " ', '" + textBox2.Text + " ', '" + textBox3.Text + "', '" + textBox8.Text + "', '" + textBox4.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "', '" + textBox7.Text + "')";
                cmd.ExecuteNonQuery();  //CommandText içindeki emri yerine getirir!!
                con.Close();
                Listeleme();
            }
            catch(Exception ex)
            {
                MessageBox.Show($"UPS! {ex.Message} Something goes wrong!!");
                con.Close();
                Listeleme();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult sonuc = MessageBox.Show("Are you sure to delete student data?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (sonuc == DialogResult.Yes)
            {
                con.Open();
                cmd.Connection = con;
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ID"].Value);
                cmd.CommandText = "Delete from Student where ID = '" + id + "' ";
                cmd.ExecuteNonQuery();
                con.Close();
                Listeleme();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
              String conString = "Data Source=StudentDB.db;verison=3";
              SQLiteConnection conn = new SQLiteConnection(conString);
               try
               {

                   conn.Open();
                   SQLiteCommand cmd = new SQLiteCommand();
                   cmd.CommandText =
                       "UPDATE Student SET Name=@N,Surname=@S,Gender=@G,Class=@C,CallNumber=@U,ParentName=@R,ParentCall=@L x";
                    cmd.Prepare();
                    cmd.Parameters.AddWithValue("@N", textBox2.Text);
                    cmd.Parameters.AddWithValue("@S", textBox3.Text);
                    cmd.Parameters.AddWithValue("@G", textBox8.Text);
                    cmd.Parameters.AddWithValue("@U", textBox5.Text);
                    cmd.Parameters.AddWithValue("@R", textBox6.Text);
                    cmd.Parameters.AddWithValue("@L", textBox7.Text);
                    cmd.Parameters.AddWithValue("@C", textBox4.Text);
                    cmd.Parameters.AddWithValue("@I", textBox1.Text);
                cmd.Connection = conn;
                   cmd.ExecuteNonQuery();
                   conn.Close();
                   Listeleme();
               }
               catch (Exception ex)
               {
                   MessageBox.Show($"ERROR:{ex.Message}");
               }
            /*int secilen = Convert.ToInt32(dataGridView1.CurrentRow.Cells["ID"].Value);
            con.Open();
            cmd.Connection = con;*/
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(textBox1.Text);
                con.Open();
                cmd.Connection = con;
                cmd.CommandText = "Select * from Student where ID= '" + id + "' ";
                okuyucu = cmd.ExecuteReader();
                okuyucu.Read();
                textBox1.Text = okuyucu["ID"].ToString();
                textBox2.Text = okuyucu["Name"].ToString();
                textBox3.Text = okuyucu["Surname"].ToString();
                textBox8.Text = okuyucu["Gender"].ToString();
                textBox4.Text = okuyucu["Class"].ToString();
                textBox5.Text = okuyucu["CallNumber"].ToString();
                textBox6.Text = okuyucu["ParentName"].ToString();
                textBox7.Text = okuyucu["ParentCall"].ToString();
                okuyucu.Close();
                con.Close();
            }
            catch
            {
                MessageBox.Show("The ID you entered is invalid!!!");
                okuyucu.Close();
                con.Close();
            }
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = dataGridView1.CurrentRow.Cells["ID"].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells["Name"].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells["Surname"].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells["Gender"].Value.ToString();
            textBox5.Text = dataGridView1.CurrentRow.Cells["Class"].Value.ToString();
            textBox6.Text = dataGridView1.CurrentRow.Cells["CallNumber"].Value.ToString();
            textBox7.Text = dataGridView1.CurrentRow.Cells["ParentName"].Value.ToString();
            textBox8.Text = dataGridView1.CurrentRow.Cells["ParentCall"].Value.ToString();
        }

        
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
